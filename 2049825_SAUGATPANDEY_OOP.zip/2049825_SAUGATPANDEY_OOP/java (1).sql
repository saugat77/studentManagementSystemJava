-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 16, 2021 at 04:23 AM
-- Server version: 10.4.17-MariaDB
-- PHP Version: 8.0.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `java`
--

-- --------------------------------------------------------

--
-- Table structure for table `courses`
--

CREATE TABLE `courses` (
  `CourseCode` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Instructor` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `LEVEL` varchar(5) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `courses`
--

INSERT INTO `courses` (`CourseCode`, `Instructor`, `LEVEL`) VALUES
('Bit4001', 'Rudra Raj Singh', '4'),
('Bit4002', 'Shanta Subedi', '4'),
('Bit4003', 'Sulav Lama', '4'),
('Bit4004', 'Sudeep Pandey', '4'),
('Bit5001', 'Saugat Thakur', '5'),
('Bit5002', 'Saurav Podel', '5'),
('Bit5003', 'Samep yadav', '5'),
('Bit5004', 'Sagar Podel', '5'),
('Bit6001', 'Krishna Ghimire', '6'),
('Bit6002', 'Sandesh Belbase', '6'),
('Bit6003', 'Sandesh Pudasaini', '6'),
('Bit6004', 'Hemanta Sharma', '6'),
('Bit6005', 'Manir Thakuri', '6');

-- --------------------------------------------------------

--
-- Table structure for table `instructor`
--

CREATE TABLE `instructor` (
  `Name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ID` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Age` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Code` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `gender` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `instructor`
--

INSERT INTO `instructor` (`Name`, `ID`, `Age`, `Code`, `gender`) VALUES
('Hemanta Sharma', 'ins403', '41', 'Bit6004', 'male'),
('Manir Thakuri', 'ins402', '40', 'Bit6005', 'male'),
('Rudra Raj Singh', 'ins406', '40', 'Bit4001', 'male'),
('Sandesh belbase', 'ins405', '42', 'Bit6002', 'male'),
('Sandesh Pudasaini', 'ins404', '40', 'Bit6003', 'male'),
('Saugat Thakur', 'ins400', '31', 'Bit5001', 'Male');

-- --------------------------------------------------------

--
-- Table structure for table `marks`
--

CREATE TABLE `marks` (
  `m1` int(11) NOT NULL,
  `m2` int(11) NOT NULL,
  `m3` int(11) NOT NULL,
  `m4` int(11) NOT NULL,
  `ROLL NO` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `marks`
--

INSERT INTO `marks` (`m1`, `m2`, `m3`, `m4`, `ROLL NO`) VALUES
(50, 60, 70, 80, 1),
(40, 50, 60, 70, 44);

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE `student` (
  `ROLL NO.` int(11) NOT NULL,
  `First name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Last name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Age` int(11) NOT NULL,
  `LEVEL` varchar(11) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Gender` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Username` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Password` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`ROLL NO.`, `First name`, `Last name`, `Age`, `LEVEL`, `Gender`, `Username`, `Password`) VALUES
(1, 'Saugat', 'Pandey', 20, '4', 'male', 'saugat7', 'Saugat123'),
(2, 'sunil', 'thapa', 19, '4', 'male', 'sunil4', 'sunil123'),
(5, 'Cyntheia', 'Pandey', 19, '4', 'Male', 'cyntheia', 'Cyntheia'),
(7, 'Katrina ', 'Kaif', 21, '4', 'Female', 'Katrina', 'KAtrina123'),
(8, 'Alice', 'Rai', 20, '5', 'Male', 'Alice', 'Alice123'),
(9, 'Alisha', 'Rai', 20, '5', 'Female', 'Alisha', 'Alicshe123'),
(10, 'Elina', 'Rai', 20, '4', 'Female', 'Elina', 'Elina123'),
(11, 'Europe', 'Khatiwada', 21, '4', 'Male', 'Europe', 'Europe'),
(12, 'Asia', 'Khatiwada', 21, '6', 'Male', 'Asia', 'Europe'),
(13, 'zyan', 'Malik', 21, '6', 'Male', 'zayn', 'Zayn123'),
(14, 'ram', 'pun', 22, '5', 'Male', 'Ram3', 'Ram123'),
(15, 'ram', 'shahi', 22, '6', 'Male', 'Ram6', 'Ram123'),
(16, 'ram raj', 'shahi', 22, '5', 'Male', 'raj', 'Ram123'),
(17, 'raj', 'shahi', 22, '5', 'Male', 'raj4', 'Ram123'),
(20, 'Sagar', 'Gurung', 20, '5', 'male', 'sagar5', 'Sagar123'),
(44, 'saroj', 'regmi', 20, '6', 'Male', 'saroj56', 'Saroj123'),
(45, 'sapana', 'regmi', 20, '6', 'female', 'sapana8', 'Sapana123'),
(60, 'Eren', 'jaeger', 20, '5', 'Male', 'Eren', 'Eren123'),
(444, 'sabin', 'rai', 20, '6', 'Male', 'sabin6', 'Sabin123');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `courses`
--
ALTER TABLE `courses`
  ADD PRIMARY KEY (`CourseCode`);

--
-- Indexes for table `instructor`
--
ALTER TABLE `instructor`
  ADD PRIMARY KEY (`Name`),
  ADD UNIQUE KEY `ID` (`ID`),
  ADD KEY `code` (`Code`);

--
-- Indexes for table `marks`
--
ALTER TABLE `marks`
  ADD PRIMARY KEY (`ROLL NO`),
  ADD KEY `ROLL NO` (`ROLL NO`);

--
-- Indexes for table `student`
--
ALTER TABLE `student`
  ADD PRIMARY KEY (`ROLL NO.`),
  ADD UNIQUE KEY `Username` (`Username`);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `instructor`
--
ALTER TABLE `instructor`
  ADD CONSTRAINT `code` FOREIGN KEY (`Code`) REFERENCES `courses` (`CourseCode`);

--
-- Constraints for table `marks`
--
ALTER TABLE `marks`
  ADD CONSTRAINT `roll no.` FOREIGN KEY (`ROLL NO`) REFERENCES `student` (`ROLL NO.`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
