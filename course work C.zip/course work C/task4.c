#include<stdio.h>
#include"lodepng.h"
void main(){
	unsigned char *image;
	unsigned int w,h;
	unsigned error;
	lodepng_decode32_file(&image,&w,&h);
	if(error){
		printf("%d %s",error,lodepng_error_text(error));
	}
	
		printf("%d %d\n",w,h);
		int i,j;
	for(i=0;i<h;i=i+4){
	for (j=0;j<w;j++){
    	int r=image[4*j*w*h + 0];
	    int	g=image[4*j*w*h + 1];
	    int	b=image[4*j*w*h + 2];
	    int	a=image[4*j*w*h + 3];
		printf("[%3d %3d %3d %3d]\t",r,g,b,a);
	}printf("\n");
	
	}
	free(image);
	unsigned char *png;
	size_t pngsize;
	error = lodepng_encode32(&png,&pngsize,image,w,h);
	if(!error){
		lodepng_save_file(png,pngsize,finalfile);
	}
	}

