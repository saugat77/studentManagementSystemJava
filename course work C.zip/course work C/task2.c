#include<stdio.h>
#include<pthread.h>
#include<stdlib.h>

float PIE = 0;
//making structure
struct structpi{
	long long  start;
	long long end;
	int threadids;
};

void *fun(void *p){
	struct structpi *t = p;
	long long  start = t->start;
	long long  end = t->end;
	int threadids = t->threadids;
	int result;
	long long i;
	double f;

	for (i = start;i<=end;i++){    
		if (i % 2) {
			result = -1;
		} else {
			result = 1;
		}
		f = ((double)result) / (2 * i + 1);	   
		PIE =PIE + 4 * f;         
	}
	pthread_exit(0);	
}

void main(){
	long long compCount;
	int threadCount;
	//taking inputs
	printf("Enter number of computation you want: ");
	scanf("%lld",&compCount);

	printf("Enter number of thread you want: ");
	scanf("%d",&threadCount);

	int slicelist[threadCount];		
	int startlist[threadCount];
	int endlist[threadCount];
	int rem = compCount % threadCount;
	int i,j,l,m,n,k;
	
	for (i = 0; i<threadCount; i++){
		slicelist[i] = compCount / threadCount;
	}
	for (j=0;j<rem;j++){
		slicelist[j] = slicelist[j]+1;
	}
	for (l=0; l<threadCount; l++){
		if(l ==0){
			startlist[l] = 0;
		}else{
			startlist[l] = endlist[l-1] + 1;
		}
		endlist[l] = startlist[l] + slicelist[l] - 1;
	}
	struct structpi mainstruct[threadCount];
	pthread_t threadids[threadCount];
	
	for (m=0; m <threadCount; m++){
		mainstruct[m].start = startlist[m];
		mainstruct[m].end = endlist[m];
		mainstruct[m].threadids = threadids[m];
	}
		//making multiple threads
		
	for (k=0;k<threadCount;k++){
		pthread_create(&threadids[k],NULL,fun,&mainstruct[k]);
	}
	
	for (n=0;n<threadCount;n++){
		pthread_join(threadids[n],NULL);
	}	

	printf("The estimated value of PI  is: %f",PIE);
}

