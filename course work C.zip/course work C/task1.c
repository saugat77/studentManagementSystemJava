#include<stdio.h>
#include<stdlib.h>
#include<math.h>


void file ()
{
 FILE * f1,*f2,*f3,*f4,*f5;
 char ch;
 f1=fopen("datasetLR1.txt","r");
 f2=fopen("datasetLR2.txt","r");
 f3=fopen("datasetLR3.txt","r");
 f4=fopen("datasetLR4.txt","r");
f5 = fopen("data.txt","w");
 
 if (f1 == NULL || f2 == NULL || f3 == NULL || f4 == NULL  ) 
   { 
         puts("Could not open files"); 
         exit(0); 
   } 
  
   // Copy contents of first file  
   while ((ch = fgetc(f1)) != EOF) 
      fputc(ch, f5); 
  
   // Copy contents of second file 
   while ((ch = fgetc(f2)) != EOF) 
      fputc(ch, f5); 
      
       // Copy contents of third file 
   while ((ch = fgetc(f3)) != EOF) 
      fputc(ch, f5); 
      
       // Copy contents of fourth file 
   while ((ch = fgetc(f4)) != EOF) 
      fputc(ch, f5); 
  
   printf("Merged file1, file2, file3 and file4\n"); 
  
    fclose(f1);
    fclose(f2);
    fclose(f3);
    fclose(f4);
 	fclose(f5);
 }
void main(){
	//taking input from file
	float x;
	float y;
	float n = 0;
	float sum_x,sum_y=0;
	float sum_xy=0;
	float sum_xsq=0;
	float a,b;
	file();
     FILE *f5 = fopen("data.txt","r");
 	while(!feof(f5)){
 		fscanf(f5,"%f,%f\n",&x,&y);
 		n++;
 		sum_x=sum_x + x;
 		sum_y=sum_y + y;
 		sum_xy = sum_xy + x  * y;
 		sum_xsq =sum_xsq + x * x;
    }
	 printf("\nsum of x and y in files are  %f and %f respectively",sum_x,sum_y);
    	printf("\nthere are %f lines ",n);
    	printf("\n sum of x*y is %f",sum_xy);
    	printf ("\nsum of x square is %f\n" ,sum_xsq);
    	   
    	   
    	   // now linear regression
    	   
    	   a = (sum_y*sum_xsq - sum_x * sum_xy) / (n*sum_xsq - sum_x*sum_x);
    	   printf("\n the value of A is %f",a);
    	   b = (n* sum_xy - sum_x * sum_y) / (n * sum_xsq - sum_x * sum_x);
    	   printf("\n the value of B is %f\n",b);
    	   
    	   // now y_intercept 
    	   
    	  float y_intercept,X;
    	  printf("\nenter value you want for x :   ");
    	  scanf("%f",&X);
    	  y_intercept = X *b + a;
		  printf("the predicted value of y is: %f ",y_intercept); 

	
 }
 
 
 
 

