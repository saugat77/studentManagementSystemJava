#include<stdio.h>
#include<pthread.h>
#include<stdlib.h>
int f = 0;
struct structpi{
	long long  start;
	long long end;
	int threadids;
};
void *fun(void *p){

   	struct structpi *t = p;
	int threadids = t->threadids;
	int result;
	long long i;
	double f;
	int x;
	FILE *f4;
	
		while(!feof(f4)){
 		fscanf(f4,"%f,%f\n",&x);
 		for (i = 2;i<=x/2;i++){   
	 if(i%2 == 0){
	 	f = 1;
	 	break;
	 } 
	 if(f==0){
	 	printf("prime no. are %d",x);
	 }
 		
    }
	pthread_exit(0);
     
}
}


void main(){
	
	
		FILE *fptr;
	char ch;
     FILE *f1,*f2,*f3,*f4; 
	 f1= fopen ("PrimeData1.txt","r");
	 f2=fopen ("PrimeData2.txt","r");
     f3 = fopen ("PrimeData3.txt","r");
	 f4 = fopen ("primedataresult.txt","w");
     
     while ((ch = fgetc(f1)) != EOF) 
      fputc(ch, f4); 
  
   while ((ch = fgetc(f2)) != EOF) 
      fputc(ch, f4); 
      

   while ((ch = fgetc(f3)) != EOF) 
      fputc(ch, f4); 
      
  
   printf("Merged file1, file2, file3\n"); 
  
    fclose(f1);
    fclose(f2);
    fclose(f3);
    fclose(f4);
 
	 
	int threadCount;
	

	printf("Enter number of thread you want: ");
	scanf("%d",&threadCount);

	int slicelist[threadCount];		
	int startlist[threadCount];
	int endlist[threadCount];
	int i,j,l,m,n,k;
	
	for (l=0; l<threadCount; l++){
		if(l ==0){
			startlist[l] = 0;
		}else{
			startlist[l] = endlist[l-1] + 1;
		}
		endlist[l] = startlist[l] + slicelist[l] - 1;
	}
	struct structpi mainstruct[threadCount];
	pthread_t threadids[threadCount];
	
	for (m=0; m <threadCount; m++){
		mainstruct[m].start = startlist[m];
		mainstruct[m].end = endlist[m];
		mainstruct[m].threadids = threadids[m];
	}
		//making multiple threads
		
	for (k=0;k<threadCount;k++){
		pthread_create(&threadids[k],NULL,fun,&mainstruct[k]);
	}
	
	for (n=0;n<threadCount;n++){
		pthread_join(threadids[n],NULL);
	}	
}


